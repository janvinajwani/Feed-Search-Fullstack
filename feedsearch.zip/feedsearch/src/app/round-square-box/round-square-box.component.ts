import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-round-square-box',
  standalone: true,
  imports: [],
  templateUrl: './round-square-box.component.html',
  styleUrl: './round-square-box.component.css'
})
export class RoundSquareBoxComponent {
  @Input() items: any[] = [];
}
