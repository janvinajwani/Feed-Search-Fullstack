import { Component, HostListener, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataModel } from './data-model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  items: any[] = [];
  pageSize: number;
  searchTerm: string = '';
  selectedSortTerm: string = '';
  totalItems: number;
  currentPage: number = 1;
  //isButtonActive: boolean = false;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    const storedPage = localStorage.getItem('currentPage');
    if (storedPage) {
      this.currentPage = parseInt(storedPage, 10);
    }
    const storedSearchTerm = localStorage.getItem('searchTerm');
    if (storedSearchTerm) {
      this.searchTerm = storedSearchTerm;
    }
    const storedSortTerm = localStorage.getItem('selectedSortTerm');
    if (storedSortTerm) {
      this.selectedSortTerm = storedSortTerm;
    }
    this.calculatePageSize();
    this.fetchData();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.calculatePageSize();
    this.fetchData();
    //if(this.searchTerm!="")this.fetchData(); // Fetch data again when window is resized
    //else this.fetchDataByValue(); // if else condition to fetch from a particular url
  }

  calculatePageSize() {
    const screenWidth = window.innerWidth;
    if (screenWidth < 768) {
      // Mobile
      this.pageSize = 2;
    } else if (screenWidth < 992) {
      // Tablet
      this.pageSize = 4;
    } else {
      // Desktop
      this.pageSize = 6;
    }
  }

  fetchData() {
    const url = `http://localhost:8008/api/feedsearch?pageNumber=${this.currentPage}&pageSize=${this.pageSize}`;
    this.http.get<DataModel[]>(url)
      .subscribe(response => {
        this.items = response;
        this.totalItems = this.items.length;
      });
  }

  toggleButtonAndSearch() {
    let searchButton = document.querySelector('.search-button');
    searchButton.classList.toggle('active-search-button');
    this.fetchDataByValue(); // 
    // Store the search term in local storage to have the same value on search box
    localStorage.setItem('searchTerm', this.searchTerm);
    //for toggling effect
    setTimeout(() => {
      searchButton.classList.toggle('active-search-button');
    }, 150);
  }


  fetchDataByValue() {
    const url = `http://localhost:8008/api/feedsearch/byvalue?searchTerm=${this.searchTerm}&pageSize=${this.pageSize}`;
    this.http.get<DataModel[]>(url)
      .subscribe(response => {
        this.items = response;
        this.totalItems = this.items.length;
      });
      this.currentPage=1;
  }

  sortBy(sortTermValue: string) {
    this.selectedSortTerm = sortTermValue;
    localStorage.setItem('selectedSortTerm', sortTermValue);
    const url = `http://localhost:8008/api/feedsearch/sort?sortTerm=${sortTermValue}&pageNumber=${this.currentPage}&pageSize=${this.pageSize}`;
    this.http.get<DataModel[]>(url)
      .subscribe(response => {
        this.items = response;
        this.totalItems = this.items.length;
      });
  }
 

  fetchPageData(page:number) {
    const url = `http://localhost:8008/api/feedsearch/page?pageNumber=${page}&pageSize=${this.pageSize}`;
    this.http.get<DataModel[]>(url)
      .subscribe(response => {
        this.items = response;
      });
  }

  changePage(page: number): void {
    this.currentPage = page;
    this.fetchPageData(page);
    localStorage.setItem('currentPage', this.currentPage.toString());
  }
}
