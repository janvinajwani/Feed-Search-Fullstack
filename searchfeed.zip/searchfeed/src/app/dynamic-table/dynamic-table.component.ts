import { Component, HostListener, Input } from '@angular/core';

@Component({
  selector: 'app-dynamic-table',
  templateUrl: './dynamic-table.component.html',
  styleUrl: './dynamic-table.component.css'
})
export class DynamicTableComponent {
  @Input() items: any[] = [];
  showDescriptionColumn = true;
  showImageColumn = true;
  showLastDateEditedColumn = true;
  showNameColumn = true;

  constructor() { }

  ngOnInit() {
    this.calculateColumnVisibility();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.calculateColumnVisibility();
  }

  calculateColumnVisibility() {
    const screenWidth = window.innerWidth;
    if (screenWidth < 768) {
      // Mobile
      this.showNameColumn = true;
      this.showDescriptionColumn = false;
      this.showImageColumn = false;
      this.showLastDateEditedColumn = true;
    } else if (screenWidth < 992) {
      // Tablet
      this.showNameColumn = true;
      this.showLastDateEditedColumn = false;
      this.showImageColumn = false;
      this.showDescriptionColumn = true;
    }
    else{
      this.showNameColumn = true;
      this.showLastDateEditedColumn = true;
      this.showImageColumn = true;
      this.showDescriptionColumn = true;
    }
    // For larger screens, all columns are visible by default
    
  }
}
