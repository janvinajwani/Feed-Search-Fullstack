export interface DataModel {
    name: string;
    image: string;
    description: string;
    dateLastEdited: string;
  }