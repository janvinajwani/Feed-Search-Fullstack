import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoundSquareBoxComponent } from './round-square-box.component';

describe('RoundSquareBoxComponent', () => {
  let component: RoundSquareBoxComponent;
  let fixture: ComponentFixture<RoundSquareBoxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RoundSquareBoxComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RoundSquareBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
